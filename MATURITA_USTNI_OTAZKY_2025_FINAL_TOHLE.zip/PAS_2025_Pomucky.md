# PC1

    - OS Windows - (účet maturita:maturita)
    - SW
        - MS Word
        - MS Excel
        - MS PowerPoint
        - MS Edge nebo jiný prohlížeč
        - MS Access
        - VirtualBox




# PC2


	(možné vytvořit jako počítač ve VirtualBox, nastavení sítě jako Bridge)
	- OS Linux (Zorin) - (účet maturita:maturita)
	- SW
		- Pycharm (sudo snap install pycharm-community --channel=stable --classic)
		- VirtualBox (sudo apt update && sudo apt install virtualbox -y) - není nutný v případě, že je PC2 instalováno jako virtuální.
		- Git (sudo apt update && sudo apt install git -y)
		- Docker(sudo apt update && sudo apt install docker.io -y)


